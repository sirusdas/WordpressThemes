<?php

// This file was added especially for the wp-signup.php and wp-activate.php files :-)

gk_load('header');
gk_load('before');

// EOF