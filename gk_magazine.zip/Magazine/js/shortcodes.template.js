/**
 *
 * -------------------------------------------
 * Script for the template shortcodes
 * -------------------------------------------
 *
 **/
// onLoad event
jQuery(window).load(function () {
    // header animation
    jQuery(document.body).addClass('loaded');
});